package com.example.engineoilreminder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private data class OilRecord(
    val date: Long, val currentKm: Long, val previousKm: Long, val intervalKm: Long
)
private data class Vehicle(
    val id: Long,
    var name: String,
    var type: String,
    var registration: String,
    var currentKm: Long,
    var lastOilKm: Long,
    var intervalKm: Long,
    var warningPercent: Int,
    var records: MutableList<OilRecord> = mutableListOf(),
    var warningSent: Boolean = false,
    var dueSent: Boolean = false
) {
    val driven: Long get() = (currentKm - lastOilKm).coerceAtLeast(0)
    val warningAt: Long get() = (intervalKm * warningPercent / 100.0).roundToInt().toLong()
    val remaining: Long get() = (intervalKm - driven).coerceAtLeast(0)
}

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("engine_oil_data", MODE_PRIVATE) }
    private val vehicles = mutableListOf<Vehicle>()
    private var selectedTab = "Home"
    private var themeChoice = "Default"
    private var language = "English"
    private var notificationsEnabled = true
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var dark = false

    private val green = Color.rgb(54, 201, 138)
    private val forest = Color.rgb(16, 35, 29)
    private val cardDark = Color.rgb(27, 53, 43)
    private val lightBg = Color.rgb(242, 248, 244)
    private val lightCard = Color.WHITE
    private val textDark = Color.rgb(24, 43, 34)
    private val mutedDark = Color.rgb(103, 126, 113)

    private val languages = listOf(
        "English", "Assamese", "Bengali", "Bodo", "Dogri", "Gujarati", "Hindi", "Kannada",
        "Kashmiri", "Konkani", "Maithili", "Malayalam", "Manipuri (Meitei)", "Marathi",
        "Nepali", "Odia", "Punjabi", "Sanskrit", "Santali", "Sindhi", "Tamil", "Telugu", "Urdu"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        themeChoice = prefs.getString("theme", "Default") ?: "Default"
        language = prefs.getString("language", "") ?: ""
        notificationsEnabled = true
        if (language.isBlank()) {
            showLanguagePicker(firstLaunch = true)
        } else {
            applyTheme()
            createNotificationChannel()
            askNotificationPermission()
            render()
        }
    }

    override fun onResume() {
        super.onResume()
        if (language.isNotBlank() && themeChoice == "Automatic") render()
    }

    private fun applyTheme() {
        dark = when (themeChoice) {
            "Dark theme" -> true
            "Automatic" -> (resources.configuration.uiMode and 0x30) == 0x20
            else -> false
        }
        window.statusBarColor = if (dark) forest else Color.rgb(232, 241, 235)
        window.navigationBarColor = if (dark) forest else Color.WHITE
        if (Build.VERSION.SDK_INT >= 26) window.decorView.systemUiVisibility = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }

    private fun bg() = if (dark) forest else lightBg
    private fun card() = if (dark) cardDark else lightCard
    private fun fg() = if (dark) Color.WHITE else textDark
    private fun muted() = if (dark) Color.rgb(168, 199, 182) else mutedDark

    private fun loadData() {
        val raw = prefs.getString("vehicles", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val records = mutableListOf<OilRecord>()
                val ra = o.optJSONArray("records") ?: JSONArray()
                for (j in 0 until ra.length()) {
                    val r = ra.getJSONObject(j)
                    records.add(OilRecord(r.optLong("date"), r.optLong("current"), r.optLong("previous"), r.optLong("interval")))
                }
                vehicles.add(Vehicle(o.optLong("id"), o.optString("name"), o.optString("type"), o.optString("registration"),
                    o.optLong("current"), o.optLong("lastOil"), o.optLong("interval", 1500), o.optInt("warning", 80), records,
                    o.optBoolean("warningSent"), o.optBoolean("dueSent")))
            }
        } catch (_: Exception) { vehicles.clear() }
    }

    private fun saveData() {
        val arr = JSONArray()
        vehicles.forEach { v ->
            val o = JSONObject().put("id", v.id).put("name", v.name).put("type", v.type)
                .put("registration", v.registration).put("current", v.currentKm).put("lastOil", v.lastOilKm)
                .put("interval", v.intervalKm).put("warning", v.warningPercent)
                .put("warningSent", v.warningSent).put("dueSent", v.dueSent)
            val rs = JSONArray()
            v.records.forEach { r -> rs.put(JSONObject().put("date", r.date).put("current", r.currentKm).put("previous", r.previousKm).put("interval", r.intervalKm)) }
            o.put("records", rs)
            arr.put(o)
        }
        prefs.edit().putString("vehicles", arr.toString()).apply()
    }

    private fun render() {
        applyTheme()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg())
            // Android 15 enforces edge-to-edge for apps targeting API 35.
            // Apply system-bar insets so the header does not sit under the status bar
            // and the bottom navigation stays above the gesture/navigation area.
            setOnApplyWindowInsetsListener { view, insets ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    view.setPadding(view.paddingLeft, bars.top, view.paddingRight, bars.bottom)
                } else {
                    @Suppress("DEPRECATION")
                    view.setPadding(
                        view.paddingLeft,
                        insets.systemWindowInsetTop,
                        view.paddingRight,
                        insets.systemWindowInsetBottom
                    )
                }
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(14)); setBackgroundColor(if (dark) forest else lightBg)
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        titleCol.addView(txt("Engine Oil Reminder", 22, fg(), true))
        titleCol.addView(txt("Vehicle maintenance made simple", 12, muted()))
        header.addView(titleCol)
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(14)) }
        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(card()); setPadding(dp(4), dp(8), dp(4), dp(8)) }
        listOf("Home" to "⌂", "Vehicles" to "▣", "History" to "◷", "Settings" to "⚙").forEach { (label, symbol) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(4), dp(3), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                isClickable = true
                isFocusable = true
                setOnClickListener { selectedTab = label; render() }
            }
            val activeColor = if (selectedTab == label) green else muted()
            item.addView(TextView(this).apply {
                text = symbol
                gravity = Gravity.CENTER
                textSize = 23f
                setTextColor(activeColor)
                typeface = Typeface.DEFAULT_BOLD
            })
            item.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 12f
                setTextColor(activeColor)
                typeface = Typeface.DEFAULT_BOLD
            })
            nav.addView(item)
        }
        root.addView(nav)
        setContentView(root)
        when (selectedTab) {
            "Home" -> showHome()
            "Vehicles" -> showVehicles()
            "History" -> showHistory()
            else -> showSettings()
        }
    }

    private fun showHome() {
        content.addView(txt("Dashboard", 20, fg(), true))
        content.addView(txt("Your vehicles, sorted by name", 12, muted()))
        content.addView(space(12))
        if (vehicles.isEmpty()) {
            content.addView(emptyCard("No vehicles added yet", "Add a vehicle to start tracking oil changes."))
            content.addView(actionButton("＋  Add New Vehicle") { showVehicleDialog(null) })
            return
        }
        vehicles.sortedBy { it.name.lowercase(Locale.ROOT) }.forEach { v -> content.addView(vehicleCard(v, true)) }
        content.addView(actionButton("＋  Add New Vehicle") { selectedTab = "Vehicles"; render(); showVehicleDialog(null) })
    }

    private fun showVehicles() {
        content.addView(txt("Vehicles", 20, fg(), true))
        content.addView(txt("Manage each vehicle separately", 12, muted()))
        content.addView(space(12))
        if (vehicles.isEmpty()) content.addView(emptyCard("No vehicles", "Add your first vehicle."))
        vehicles.sortedBy { it.name.lowercase(Locale.ROOT) }.forEach { v ->
            content.addView(vehicleCard(v, false))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(smallButton("Edit") { showVehicleDialog(v) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(smallButton("Update KM") { showKmDialog(v) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(smallButton("Oil Changed") { showOilChangeDialog(v) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            content.addView(row)
            content.addView(smallButton("Delete vehicle") { confirmDelete(v) })
            content.addView(space(10))
        }
        content.addView(actionButton("＋  Add New Vehicle") { showVehicleDialog(null) })
    }

    private fun vehicleCard(v: Vehicle, compact: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); setBackgroundColor(card())
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(txt("${v.name} · ${v.type}", 16, fg(), true), LinearLayout.LayoutParams(0, -2, 1f))
        val status = if (v.driven >= v.intervalKm) "OIL DUE" else if (v.driven >= v.warningAt) "WARNING" else "NORMAL"
        top.addView(txt(status, 11, if (status == "OIL DUE") Color.rgb(235, 99, 89) else green, true))
        box.addView(top)
        if (v.registration.isNotBlank()) box.addView(txt(v.registration, 11, muted()))
        box.addView(space(8))
        box.addView(txt("Current odometer", 11, muted()))
        box.addView(txt("${v.currentKm} KM", 25, fg(), true))
        box.addView(txt("Last oil change: ${v.lastOilKm} KM", 12, muted()))
        box.addView(txt("Run since oil change: ${v.driven} KM / ${v.intervalKm} KM", 12, fg()))
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = ((v.driven.toDouble() / v.intervalKm.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100)
            progressTintList = android.content.res.ColorStateList.valueOf(if (v.driven >= v.intervalKm) Color.rgb(235, 99, 89) else green)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) Color.rgb(49, 83, 68) else Color.rgb(219, 232, 223))
        }
        box.addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(8); bottomMargin = dp(6) })
        box.addView(txt(if (v.driven >= v.intervalKm) "Oil change required" else "${v.remaining} KM remaining", 12,
            if (v.driven >= v.intervalKm) Color.rgb(235, 99, 89) else muted(), true))
        if (!compact) {
            box.addView(txt("Warning at ${v.warningPercent}% (${v.warningAt} KM) · Interval ${v.intervalKm} KM", 11, muted()))
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        box.layoutParams = params
        return box
    }

    private fun showHistory() {
        content.addView(txt("Oil Change History", 20, fg(), true))
        content.addView(txt("Previous oil changes for all vehicles", 12, muted()))
        content.addView(space(12))
        val entries = vehicles.flatMap { v -> v.records.map { Triple(v, it, v.name) } }.sortedByDescending { it.second.date }
        if (entries.isEmpty()) content.addView(emptyCard("No history yet", "Records appear here after you confirm an oil change."))
        entries.forEach { (v, r, _) ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)); setBackgroundColor(card()) }
            box.addView(txt(v.name, 15, fg(), true))
            box.addView(txt("${r.currentKm} KM · ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(r.date))}", 14, fg()))
            box.addView(txt("Previous reading ${r.previousKm} KM · ${r.currentKm - r.previousKm} KM run · Interval ${r.intervalKm} KM", 11, muted()))
            box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
            content.addView(box)
        }
    }

    private fun showSettings() {
        content.addView(txt("Settings", 20, fg(), true))
        content.addView(space(10))
        content.addView(sectionTitle("Appearance"))
        val themeSpinner = Spinner(this)
        themeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Default", "Dark theme", "Automatic"))
        themeSpinner.setSelection(listOf("Default", "Dark theme", "Automatic").indexOf(themeChoice).coerceAtLeast(0))
        themeSpinner.onItemSelectedListener = simpleListener { choice ->
            if (choice != themeChoice) { themeChoice = choice; prefs.edit().putString("theme", choice).apply(); render() }
        }
        content.addView(themeSpinner)
        content.addView(space(12))
        content.addView(sectionTitle("Language"))
        content.addView(txt(language, 14, muted()))
        content.addView(smallButton("Change language") { showLanguagePicker(false) })
        content.addView(space(12))
        content.addView(sectionTitle("About"))
        content.addView(txt("Engine Oil Reminder · Version 2.2", 12, muted()))
        content.addView(txt("Vehicle data is stored locally on this device. There is no backup or restore feature.", 12, muted()))
    }

    private fun showVehicleDialog(existing: Vehicle?) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = editField("Vehicle name", existing?.name ?: "")
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Bike", "Scooter", "Car", "Truck", "Other")) }
        if (existing != null) type.setSelection(listOf("Bike", "Scooter", "Car", "Truck", "Other").indexOf(existing.type).coerceAtLeast(0))
        val registration = editField("Registration number (optional)", existing?.registration ?: "")
        val current = editField("Current odometer reading (KM)", existing?.currentKm?.toString() ?: "", true)
        val lastOil = editField(if (existing == null) "Last oil-change odometer reading (KM)" else "Last oil-change reading (KM) — locked", existing?.lastOilKm?.toString() ?: "", true).apply { isEnabled = existing == null }
        val interval = editField("Oil-change interval (KM)", existing?.intervalKm?.toString() ?: "1500", true)
        val warning = editField("Warning percentage (e.g. 80)", existing?.warningPercent?.toString() ?: "80", true)
        form.addView(fieldLabel("Vehicle name")); form.addView(name)
        form.addView(fieldLabel("Vehicle type")); form.addView(type)
        form.addView(fieldLabel("Registration number (optional)")); form.addView(registration)
        form.addView(fieldLabel("Current odometer reading (KM)")); form.addView(current)
        form.addView(fieldLabel("Last oil-change odometer reading (KM)")); form.addView(lastOil)
        form.addView(fieldLabel("Oil-change interval (KM)")); form.addView(interval)
        form.addView(fieldLabel("Warning percentage (1–99)")); form.addView(warning)
        val scroll = ScrollView(this).apply { addView(form) }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Add New Vehicle" else "Edit Vehicle")
            .setView(scroll).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim()
                val c = current.text.toString().toLongOrNull()
                val l = lastOil.text.toString().toLongOrNull()
                val i = interval.text.toString().toLongOrNull()
                val w = warning.text.toString().toIntOrNull()
                when {
                    n.isBlank() -> name.error = "Enter a vehicle name"
                    c == null || l == null || i == null || i <= 0 -> Toast.makeText(this, "Enter valid odometer and interval values", Toast.LENGTH_LONG).show()
                    l > c -> Toast.makeText(this, "Last oil-change reading cannot exceed current reading", Toast.LENGTH_LONG).show()
                    w == null || w !in 1..99 -> Toast.makeText(this, "Warning percentage must be between 1 and 99", Toast.LENGTH_LONG).show()
                    else -> {
                        if (existing == null) {
                            vehicles.add(Vehicle(System.currentTimeMillis(), n, type.selectedItem.toString(), registration.text.toString().trim(), c, l, i, w))
                        } else {
                            val thresholdsChanged = existing.intervalKm != i || existing.warningPercent != w
                            existing.name = n; existing.type = type.selectedItem.toString(); existing.registration = registration.text.toString().trim()
                            existing.currentKm = c; existing.intervalKm = i; existing.warningPercent = w
                            if (thresholdsChanged) { existing.warningSent = false; existing.dueSent = false }
                            // Last oil-change baseline and history are intentionally not editable after creation.
                        }
                        saveData(); dialog.dismiss(); render(); checkThresholds()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun showKmDialog(v: Vehicle) {
        val input = editField("Current odometer reading (KM)", v.currentKm.toString(), true)
        AlertDialog.Builder(this).setTitle("Update ${v.name}").setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Update", null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val km = input.text.toString().toLongOrNull()
                    if (km == null || km < v.lastOilKm) input.error = "Reading cannot be lower than the last oil-change reading"
                    else { val old = v.driven; v.currentKm = km; saveData(); d.dismiss(); render(); checkThresholds(v, old) }
                } }
                d.show()
            }
    }

    private fun showOilChangeDialog(v: Vehicle) {
        val input = editField("Odometer reading after oil change (KM)", v.currentKm.toString(), true)
        AlertDialog.Builder(this).setTitle("Confirm oil change – ${v.name}")
            .setMessage("Only confirm after the engine oil has actually been changed. This saves a permanent history record.")
            .setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save oil change", null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val km = input.text.toString().toLongOrNull()
                    if (km == null || km < v.currentKm) input.error = "Reading cannot be lower than current odometer"
                    else {
                        val previous = v.lastOilKm
                        v.records.add(OilRecord(System.currentTimeMillis(), km, previous, v.intervalKm))
                        v.currentKm = km; v.lastOilKm = km; v.warningSent = false; v.dueSent = false
                        saveData(); d.dismiss(); render()
                        Toast.makeText(this, "Oil change saved in history", Toast.LENGTH_SHORT).show()
                    }
                } }
                d.show()
            }
    }

    private fun confirmDelete(v: Vehicle) {
        AlertDialog.Builder(this).setTitle("Delete ${v.name}?")
            .setMessage("This permanently deletes the vehicle and all its oil-change history. This cannot be undone.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete permanently") { _, _ -> vehicles.remove(v); saveData(); render() }.show()
    }

    private fun checkThresholds(only: Vehicle? = null, previousDriven: Long = -1) {
        if (!notificationsEnabled) return
        val list = if (only == null) vehicles else listOf(only)
        list.forEach { v ->
            val before = if (previousDriven >= 0) previousDriven else 0L
            if (!v.warningSent && v.driven >= v.warningAt && v.driven < v.intervalKm && before < v.warningAt) {
                sendNotification(v, "Oil change approaching", "${v.name} has run ${v.driven} KM. Oil change is approaching.")
                v.warningSent = true
            }
            if (!v.dueSent && v.driven >= v.intervalKm && before < v.intervalKm) {
                sendNotification(v, "Oil change due", "${v.name} has reached ${v.driven} KM. Please change the engine oil.")
                v.dueSent = true
            }
        }
        saveData()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("oil_reminders", "Oil change reminders", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
    }
    private fun sendNotification(v: Vehicle, title: String, message: String) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(this, "oil_reminders") else android.app.Notification.Builder(this)
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(message).setAutoCancel(true).build()
        manager.notify((v.id % Int.MAX_VALUE).toInt(), notification)
    }

    private fun showLanguagePicker(firstLaunch: Boolean) {
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, languages) }
        if (language.isNotBlank()) spinner.setSelection(languages.indexOf(language).coerceAtLeast(0))
        AlertDialog.Builder(this).setTitle("Choose Your Language").setMessage("Select your preferred app language")
            .setView(spinner).setCancelable(!firstLaunch).setPositiveButton("Continue") { _, _ ->
                language = spinner.selectedItem.toString(); prefs.edit().putString("language", language).apply()
                createNotificationChannel(); askNotificationPermission(); render()
            }.apply { if (!firstLaunch) setNegativeButton("Cancel", null) }.show()
    }

    private fun editField(hintText: String, value: String, numeric: Boolean = false): EditText = EditText(this).apply {
        hint = hintText; setText(value); textSize = 16f; setTextColor(fg()); setHintTextColor(muted())
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        setPadding(dp(10), dp(7), dp(10), dp(7))
    }
    private fun fieldLabel(s: String) = TextView(this).apply { text = s; textSize = 12f; setTextColor(muted()); setPadding(0, dp(8), 0, 0) }
    private fun sectionTitle(s: String) = txt(s, 15, fg(), true)
    private fun emptyCard(title: String, body: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(18)); setBackgroundColor(card())
        addView(txt(title, 16, fg(), true)); addView(txt(body, 12, muted()))
    }
    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(36, 155, 105))
        setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) }
    }
    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 11f; setTextColor(if (dark) Color.WHITE else textDark)
        backgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) cardDark else Color.rgb(225, 238, 229))
        setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(42)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
    }
    private fun txt(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun simpleListener(onSelected: (String) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { onSelected(parent?.getItemAtPosition(position)?.toString() ?: "Default") }
    }
}
