# Engine Oil Reminder – Android Studio project

A native Kotlin Android project for the Engine Oil Reminder app.

## Included in this project

- Material You-inspired blue and navy visual theme and modern dashboard layout
- Default, Dark theme, and Automatic theme choices
- Four bottom tabs: Dashboard, Vehicles, History, Settings
- Add multiple vehicles (Bike, Scooter, Car, Truck, Other)
- Vehicle name, type, optional registration, current odometer, last oil-change odometer, oil interval, and warning percentage
- Vehicle cards sorted alphabetically
- Full vehicle cards with current odometer, last oil-change reading, distance run, interval, progress, remaining distance, and status
- Manual and quick odometer updates
- Per-vehicle warning percentage and oil interval
- Warning and due notifications when a user updates the odometer and crosses the relevant threshold
- Explicit oil-change confirmation before resetting the distance counter
- Oil-change history records date, new reading, previous reading, distance run, and interval
- Vehicle editing while keeping previous oil-change baseline and history protected
- Permanent vehicle deletion with a confirmation dialog
- Local on-device data storage; no backup/restore and no app lock
- First-launch language selector listing English plus all 22 scheduled Indian languages

## Important implementation notes

1. **Notifications are evaluated when the user updates a vehicle's odometer.** The app cannot know real-world distance travelled automatically because it does not connect to the vehicle's odometer.
2. Android 13 and newer require notification permission. The app requests it when first launched.
3. The language picker includes English and all 22 scheduled Indian languages. This starter project currently stores the selected language, but the full interface translation catalog for all 23 choices is not yet bundled. Full professional translations and script/layout QA are required before claiming complete multilingual UI support.
4. Vehicle data is stored locally in app preferences. Uninstalling the app or clearing its data removes those records. There is no backup/restore feature, as requested.
5. Oil-change history is append-only in the UI. Editing a vehicle does not change past history records or its last oil-change baseline.

## Build an APK

This workspace contains the Android Studio source project, not a compiled APK. To build the APK:

1. Install Android Studio on a computer.
2. Open this `EngineOilReminder_Final` folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if Android Studio requests it.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK output location.

Recommended final QA before release: test add/edit/delete, odometer corrections, threshold crossings, notifications on Android 13+, theme changes including system dark-mode changes, and each localized UI translation after it is added.


## Version 2.1 layout fix
- Applies Android system-bar insets to the app root, preventing the header from overlapping the status/notification bar and keeping bottom navigation clear of the system navigation area.


## Version 2.2 changes
- Removed the decorative green dot from the header.
- Removed the notification toggle from Settings; automatic oil reminders remain active.
- Enlarged bottom-navigation icons and made all navigation labels bold.
- Added a launcher app icon using the supplied oil-can artwork.


## Version 2.3 – Large odometer readings
- Odometer and interval calculations use 64-bit integer values.
- Kilometre values are displayed with Indian digit grouping (for example, 4,00,000 and 10,00,000).
- Numeric entries accept comma-separated values as well as plain digits.


## Version 2.4 – Navigation and dark-theme refinements
- Corrected dark-theme appearance dropdown text and popup colours for readability.
- Renamed the Home navigation tab to Dashboard.
- Added the user's dashboard, motorcycle, and history icons to navigation.
- Styled navigation icon tiles with a Racing Green gradient; retained the gear symbol for Settings.


## Version 2.4.1 build fix
- Removed an invalid `gravity` assignment from a `FrameLayout`; child icon gravity remains centered through its `FrameLayout.LayoutParams`.


## Version 2.5 – Material You-inspired blue theme
- Replaced the green palette with a coordinated blue and navy palette.
- Updated light and dark backgrounds, cards, text, status/navigation bars, buttons, progress accents, and navigation icon gradients.
- Kept the Dashboard, Vehicles, History, and Settings navigation structure and supplied custom navigation icons.
- Kept existing vehicle storage and odometer calculation logic unchanged.


## Version 2.5.1 – Stability and build fixes
- Replaced TextView gravity Kotlin property assignments with explicit `setGravity()` calls to avoid the reported unresolved-reference compiler issue.
- Updated the Android theme accent and system-bar fallback colours to match the blue palette.
- Made warning-threshold arithmetic safe for very large 64-bit odometer intervals.
- Rejects negative odometer values, including pasted input.
- Notification delivery now returns a success result; a denied notification permission no longer marks an alert as already sent.
- Threshold alerts can retry on a later odometer update if permission was previously denied.
- Requests notification permission on subsequent launches when Android still allows the permission prompt.
- Requests a fresh window-insets dispatch after the root view is attached.


## Version 2.5.2 – Stability and Material You icon update
- Replaced the launcher icon's remaining green artwork with a blue Material You-style gradient gamepad icon at all Android launcher densities.
- Kept all odometer values as 64-bit integers and changed warning-threshold percentage calculation to integer arithmetic to avoid floating-point rounding on large values.
- Prevented editing or updating a vehicle's odometer to a value lower than its previous reading.
- Re-checks pending reminders after Android notification permission is granted.
- Confirmed that the current MainActivity source uses `setGravity(...)` and `Gravity.CENTER` layout parameters; it contains no invalid lowercase `gravity =` property assignment.
- Added a deterministic GitHub Actions workflow separately: it extracts only `EngineOilReminder_v2.5.2_Fixed.zip`, avoiding wildcard extraction of old ZIP files and the overwrite prompt.

## Build verification status
This environment does not include the Android SDK, Gradle, or Kotlin compiler, so a native Android compile could not be run here. The source has been statically inspected and patched, but the APK is not claimed as build-verified. The supplied GitHub Actions workflow is intended to perform that final Android build.


## Version 2.5.3 – Build target compatibility fix
- Set Java source and target compatibility to Java 17.
- Set Kotlin JVM target to 17.
- This aligns both compile tasks with the Java 17 toolchain used by GitHub Actions and fixes the reported inconsistent JVM-target error.


## Version 2.5.4 – Navigation and app icon update
- Replaced the Android launcher icon with the user's supplied engine-oil logo.
- Regenerated launcher icon assets for mdpi through xxxhdpi.
- Refined bottom navigation icon tiles to use larger rounded Material You-style blue tiles.
- Increased navigation icon and label sizing while retaining the supplied Dashboard, Vehicles, and History artwork.
- Kept the blue light/dark palette and Java/Kotlin JVM 17 target alignment.


## Version 2.5.5 – Navigation alignment and custom Settings icon

- Replaced the Settings navigation gear glyph with the supplied transparent gear PNG.
- Applied the same selected/unselected blue tint system used by the other navigation icons.
- Standardized navigation cell heights, icon-holder dimensions, label widths, and text baselines for more consistent alignment.
- Kept the existing Material You-inspired blue palette and application features.


## Version 2.5.6 – Sliding page transitions

- Added a short horizontal slide-and-fade transition when switching between Dashboard, Vehicles, History, and Settings.
- Moving to a later destination slides the page in from the right; moving to an earlier destination slides it in from the left.
- The animation is applied to the page content only; the bottom navigation remains stationary.


## Version 2.5.7 – Engine oil jug launcher icon
- Replaced the launcher icon with the supplied black-and-white engine-oil jug artwork.
- Regenerated standard launcher icon PNGs for mdpi, hdpi, xhdpi, xxhdpi, and xxxhdpi.
- Kept the existing Material You blue theme, custom navigation icons, large odometer support, and sliding page transitions.
- Synchronized the app version shown in Settings with the Gradle version name.

- Replaced Kotlin synthetic `gravity =` assignments in navigation layouts with explicit `setGravity(...)` calls to avoid property-resolution ambiguity.
