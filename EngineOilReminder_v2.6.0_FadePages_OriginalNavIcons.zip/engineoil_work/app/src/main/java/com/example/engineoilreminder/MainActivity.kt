package com.example.engineoilreminder

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.animation.DecelerateInterpolator
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

private data class OilRecord(
    val date: Long, val currentKm: Long, val previousKm: Long, val intervalKm: Long
)
private data class Vehicle(
    val id: Long,
    var name: String,
    var type: String,
    var registration: String,
    var currentKm: Long,
    var lastOilKm: Long,
    var intervalKm: Long,
    var warningPercent: Int,
    var records: MutableList<OilRecord> = mutableListOf(),
    var warningSent: Boolean = false,
    var dueSent: Boolean = false
) {
    val driven: Long get() = (currentKm - lastOilKm).coerceAtLeast(0)
    // Integer-only percentage calculation avoids floating-point rounding for large odometer values.
    val warningAt: Long get() {
        val percent = warningPercent.coerceIn(1, 99).toLong()
        val whole = (intervalKm / 100L) * percent
        val remainder = ((intervalKm % 100L) * percent + 50L) / 100L
        return (whole + remainder).coerceIn(0L, intervalKm.coerceAtLeast(0L))
    }
    val remaining: Long get() = if (driven >= intervalKm) 0L else intervalKm - driven
}

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("engine_oil_data", MODE_PRIVATE) }
    private val vehicles = mutableListOf<Vehicle>()
    private var selectedTab = "Dashboard"
    // Page content uses a soft fade; bottom-navigation feedback remains unchanged.
    private var pendingContentFade = false
    private var themeChoice = "Automatic"
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var dark = false

    private val green = Color.rgb(78, 121, 226) // Material You-inspired blue primary
    private val forest = Color.rgb(16, 27, 43) // deep navy surface
    private val cardDark = Color.rgb(29, 46, 68)
    private val lightBg = Color.rgb(243, 247, 253)
    private val lightCard = Color.WHITE
    private val textDark = Color.rgb(25, 39, 60)
    private val mutedDark = Color.rgb(91, 111, 139)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        themeChoice = when (prefs.getString("theme", "Automatic") ?: "Automatic") {
            "Dark theme", "Dark" -> "Dark"
            "Default", "Light" -> "Light"
            else -> "Automatic"
        }
        // Language selection has been removed; the app now starts directly in English.
        applyTheme()
        createNotificationChannel()
        askNotificationPermission()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (themeChoice == "Automatic") render()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            // Retry any pending threshold alerts now that notifications are permitted.
            checkThresholds()
        }
    }

    private fun applyTheme() {
        dark = when (themeChoice) {
            "Dark" -> true
            "Automatic" -> (resources.configuration.uiMode and 0x30) == 0x20
            else -> false
        }
        window.statusBarColor = if (dark) forest else Color.rgb(235, 242, 252)
        window.navigationBarColor = if (dark) forest else Color.WHITE
        var systemUiFlags = 0
        if (!dark && Build.VERSION.SDK_INT >= 23) systemUiFlags = systemUiFlags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (!dark && Build.VERSION.SDK_INT >= 26) systemUiFlags = systemUiFlags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.decorView.systemUiVisibility = systemUiFlags
    }

    private fun bg() = if (dark) forest else lightBg
    private fun card() = if (dark) cardDark else lightCard
    private fun fg() = if (dark) Color.WHITE else textDark
    private fun muted() = if (dark) Color.rgb(185, 202, 225) else mutedDark

    // Format odometer and interval values using Indian digit grouping (e.g. 10,00,000).
    private fun km(value: Long): String =
        NumberFormat.getIntegerInstance(Locale("en", "IN")).format(value)

    // Accept plain digits or values copied with Indian/Western comma separators.
    private fun parseKm(value: String): Long? =
        value.trim().replace(",", "").replace(" ", "").toLongOrNull()

    private fun loadData() {
        val raw = prefs.getString("vehicles", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val records = mutableListOf<OilRecord>()
                val ra = o.optJSONArray("records") ?: JSONArray()
                for (j in 0 until ra.length()) {
                    val r = ra.getJSONObject(j)
                    records.add(OilRecord(r.optLong("date"), r.optLong("current"), r.optLong("previous"), r.optLong("interval")))
                }
                vehicles.add(Vehicle(o.optLong("id"), o.optString("name"), o.optString("type"), o.optString("registration"),
                    o.optLong("current"), o.optLong("lastOil"), o.optLong("interval", 1500), o.optInt("warning", 80), records,
                    o.optBoolean("warningSent"), o.optBoolean("dueSent")))
            }
        } catch (_: Exception) { vehicles.clear() }
    }

    private fun saveData() {
        val arr = JSONArray()
        vehicles.forEach { v ->
            val o = JSONObject().put("id", v.id).put("name", v.name).put("type", v.type)
                .put("registration", v.registration).put("current", v.currentKm).put("lastOil", v.lastOilKm)
                .put("interval", v.intervalKm).put("warning", v.warningPercent)
                .put("warningSent", v.warningSent).put("dueSent", v.dueSent)
            val rs = JSONArray()
            v.records.forEach { r -> rs.put(JSONObject().put("date", r.date).put("current", r.currentKm).put("previous", r.previousKm).put("interval", r.intervalKm)) }
            o.put("records", rs)
            arr.put(o)
        }
        prefs.edit().putString("vehicles", arr.toString()).apply()
    }

    private fun navigateToTab(label: String) {
        if (selectedTab == label) return
        pendingContentFade = true
        selectedTab = label
        render()
    }

    private fun render() {
        applyTheme()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg())
            // Android 15 enforces edge-to-edge for apps targeting API 35.
            // Apply system-bar insets so the header does not sit under the status bar
            // and the bottom navigation stays above the gesture/navigation area.
            setOnApplyWindowInsetsListener { view, insets ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val bars = insets.getInsets(WindowInsets.Type.systemBars())
                    view.setPadding(view.paddingLeft, bars.top, view.paddingRight, bars.bottom)
                } else {
                    @Suppress("DEPRECATION")
                    view.setPadding(
                        view.paddingLeft,
                        insets.systemWindowInsetTop,
                        view.paddingRight,
                        insets.systemWindowInsetBottom
                    )
                }
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setGravity(Gravity.CENTER_VERTICAL)
            setPadding(dp(20), dp(18), dp(20), dp(14)); setBackgroundColor(if (dark) forest else lightBg)
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        titleCol.addView(txt("Engine Oil Reminder", 22, fg(), true))
        titleCol.addView(txt("Vehicle maintenance made simple", 12, muted()))
        header.addView(titleCol)
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(14)) }
        val scroll = ScrollView(this)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setGravity(Gravity.CENTER_VERTICAL)
            setBackgroundColor(card())
            setPadding(dp(5), dp(6), dp(5), dp(6))
        }
        // Every destination uses the same icon holder, icon size, label baseline and
        // equal-width cell so the bottom navigation remains aligned on narrow screens.
        val navItems = listOf(
            Triple("Dashboard", R.drawable.nav_dashboard, R.drawable.ic_dashboard_filled),
            Triple("Vehicles", R.drawable.nav_vehicle, R.drawable.nav_vehicle),
            Triple("History", R.drawable.ic_history_filled, R.drawable.ic_history_filled),
            Triple("Settings", R.drawable.nav_settings, R.drawable.ic_settings_filled)
        )
        navItems.forEach { (label, outlineIconRes, filledIconRes) ->
            val selected = selectedTab == label
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setGravity(Gravity.CENTER_HORIZONTAL)
                setPadding(dp(2), dp(2), dp(2), dp(2))
                layoutParams = LinearLayout.LayoutParams(0, dp(76), 1f)
                isClickable = true
                isFocusable = true
                setOnClickListener { navigateToTab(label) }
            }
            // Flat navigation: no gradient, pill, or coloured icon background.
            val iconHolder = FrameLayout(this).apply {
                background = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
                layoutParams = LinearLayout.LayoutParams(dp(52), dp(48)).apply { bottomMargin = dp(3) }
                scaleX = if (selected) 0.92f else 1f
                scaleY = if (selected) 0.92f else 1f
                alpha = if (selected) 0.88f else 0.92f
            }
            val icon = ImageView(this).apply {
                setImageResource(if (selected) filledIconRes else outlineIconRes)
                setColorFilter(if (selected) Color.WHITE else if (dark) Color.rgb(176, 181, 190) else Color.rgb(112, 117, 126))
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER)
                contentDescription = label
            }
            iconHolder.addView(icon)
            item.addView(iconHolder)
            item.addView(TextView(this).apply {
                text = label
                setGravity(Gravity.CENTER)
                textSize = 12.5f
                maxLines = 1
                setTextColor(if (selected) fg() else muted())
                typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.create("sans-serif-medium", Typeface.NORMAL)
                includeFontPadding = false
                alpha = if (selected) 1f else 0.78f
            }, LinearLayout.LayoutParams(-1, dp(19)))
            nav.addView(item)
        }
        root.addView(nav)
        setContentView(root)
        root.requestApplyInsets()
        when (selectedTab) {
            "Dashboard" -> showHome()
            "Vehicles" -> showVehicles()
            "History" -> showHistory()
            else -> showSettings()
        }
        // Subtle bottom-navigation feedback: filled active icon and label fade in.
        nav.post {
            for (index in 0 until nav.childCount) {
                val item = nav.getChildAt(index) as? LinearLayout ?: continue
                val label = (item.getChildAt(1) as? TextView)?.text?.toString()
                val active = label == selectedTab
                val holder = item.getChildAt(0)
                if (active) {
                    holder.animate().scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(220L)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                    item.getChildAt(1).animate().alpha(1f).setDuration(220L).start()
                }
            }
        }
        if (pendingContentFade) {
            pendingContentFade = false
            content.translationX = 0f
            content.alpha = 0f
            content.animate()
                .alpha(1f)
                .setDuration(220L)
                .setInterpolator(android.view.animation.AccelerateDecelerateInterpolator())
                .start()
        }
    }

    private fun showHome() {
        content.addView(txt("Dashboard", 20, fg(), true))
        content.addView(txt("Your vehicles, sorted by name", 12, muted()))
        content.addView(space(12))
        if (vehicles.isEmpty()) {
            content.addView(emptyCard("No vehicles added yet", "Add a vehicle to start tracking oil changes."))
            content.addView(actionButton("＋  Add New Vehicle") { showVehicleDialog(null) })
            return
        }
        vehicles.sortedBy { it.name.lowercase(Locale.ROOT) }.forEach { v -> content.addView(vehicleCard(v, true)) }
        content.addView(actionButton("＋  Add New Vehicle") { navigateToTab("Vehicles"); showVehicleDialog(null) })
    }

    private fun showVehicles() {
        content.addView(txt("Vehicles", 20, fg(), true))
        content.addView(txt("Manage each vehicle separately", 12, muted()))
        content.addView(space(12))
        if (vehicles.isEmpty()) content.addView(emptyCard("No vehicles", "Add your first vehicle."))
        vehicles.sortedBy { it.name.lowercase(Locale.ROOT) }.forEach { v ->
            content.addView(vehicleCard(v, false))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(smallButton("Edit") { showVehicleDialog(v) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(smallButton("Update KM") { showKmDialog(v) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            row.addView(smallButton("Oil Changed") { showOilChangeDialog(v) }, LinearLayout.LayoutParams(0, dp(44), 1f))
            content.addView(row)
            content.addView(smallButton("Delete vehicle") { confirmDelete(v) })
            content.addView(space(10))
        }
        content.addView(actionButton("＋  Add New Vehicle") { showVehicleDialog(null) })
    }

    private fun vehicleCard(v: Vehicle, compact: Boolean): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); setBackgroundColor(card())
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setGravity(Gravity.CENTER_VERTICAL) }
        top.addView(txt("${v.name} · ${v.type}", 16, fg(), true), LinearLayout.LayoutParams(0, -2, 1f))
        val status = if (v.driven >= v.intervalKm) "OIL DUE" else if (v.driven >= v.warningAt) "WARNING" else "NORMAL"
        top.addView(txt(status, 11, if (status == "OIL DUE") Color.rgb(235, 99, 89) else green, true))
        box.addView(top)
        if (v.registration.isNotBlank()) box.addView(txt(v.registration, 11, muted()))
        box.addView(space(8))
        box.addView(txt("Current odometer", 11, muted()))
        box.addView(txt("${km(v.currentKm)} KM", 25, fg(), true))
        box.addView(txt("Last oil change: ${km(v.lastOilKm)} KM", 12, muted()))
        box.addView(txt("Run since oil change: ${km(v.driven)} KM / ${km(v.intervalKm)} KM", 12, fg()))
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = ((v.driven.toDouble() / v.intervalKm.coerceAtLeast(1)) * 100).toInt().coerceIn(0, 100)
            progressTintList = android.content.res.ColorStateList.valueOf(if (v.driven >= v.intervalKm) Color.rgb(235, 99, 89) else green)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) Color.rgb(54, 76, 105) else Color.rgb(220, 232, 249))
        }
        box.addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(8); bottomMargin = dp(6) })
        box.addView(txt(if (v.driven >= v.intervalKm) "Oil change required" else "${km(v.remaining)} KM remaining", 12,
            if (v.driven >= v.intervalKm) Color.rgb(235, 99, 89) else muted(), true))
        if (!compact) {
            box.addView(txt("Warning at ${v.warningPercent}% (${km(v.warningAt)} KM) · Interval ${km(v.intervalKm)} KM", 11, muted()))
        }
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        box.layoutParams = params
        return box
    }

    private fun showHistory() {
        content.addView(txt("Oil Change History", 20, fg(), true))
        content.addView(txt("Previous oil changes for all vehicles", 12, muted()))
        content.addView(space(12))
        val entries = vehicles.flatMap { v -> v.records.map { Triple(v, it, v.name) } }.sortedByDescending { it.second.date }
        if (entries.isEmpty()) content.addView(emptyCard("No history yet", "Records appear here after you confirm an oil change."))
        entries.forEach { (v, r, _) ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(13)); setBackgroundColor(card()) }
            box.addView(txt(v.name, 15, fg(), true))
            box.addView(txt("${km(r.currentKm)} KM · ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(r.date))}", 14, fg()))
            box.addView(txt("Previous reading ${km(r.previousKm)} KM · ${km(r.currentKm - r.previousKm)} KM run · Interval ${km(r.intervalKm)} KM", 11, muted()))
            box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) }
            content.addView(box)
        }
    }

    private fun showSettings() {
        content.addView(txt("Settings", 20, fg(), true))
        content.addView(space(10))
        content.addView(sectionTitle("Appearance"))
        val themeSpinner = Spinner(this)
        val themeOptions = listOf("Automatic", "Light", "Dark")
        themeSpinner.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, themeOptions) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return (super.getView(position, convertView, parent) as TextView).apply {
                    setTextColor(fg())
                    textSize = 16f
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                }
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    setTextColor(fg())
                    setBackgroundColor(card())
                    textSize = 16f
                    setPadding(dp(14), dp(12), dp(14), dp(12))
                }
            }
        }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        themeSpinner.setPopupBackgroundDrawable(android.graphics.drawable.ColorDrawable(card()))
        themeSpinner.setSelection(themeOptions.indexOf(themeChoice).coerceAtLeast(0))
        themeSpinner.onItemSelectedListener = simpleListener { choice ->
            if (choice != themeChoice) { themeChoice = choice; prefs.edit().putString("theme", choice).apply(); render() }
        }
        content.addView(themeSpinner)
        content.addView(space(12))
        content.addView(sectionTitle("About"))
        content.addView(txt("Engine Oil Reminder · Version 2.5.8", 12, muted()))
        content.addView(txt("Vehicle data is stored locally on this device. There is no backup or restore feature.", 12, muted()))
    }

    private fun showVehicleDialog(existing: Vehicle?) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val name = editField("Vehicle name", existing?.name ?: "")
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Bike", "Scooter", "Car", "Truck", "Other")) }
        if (existing != null) type.setSelection(listOf("Bike", "Scooter", "Car", "Truck", "Other").indexOf(existing.type).coerceAtLeast(0))
        val registration = editField("Registration number (optional)", existing?.registration ?: "")
        val current = editField("Current odometer reading (KM) — e.g. 400000", existing?.currentKm?.toString() ?: "", true)
        val lastOil = editField(if (existing == null) "Last oil-change reading (KM) — e.g. 250000" else "Last oil-change reading (KM) — locked", existing?.lastOilKm?.toString() ?: "", true).apply { isEnabled = existing == null }
        val interval = editField("Oil-change interval (KM) — e.g. 1500", existing?.intervalKm?.toString() ?: "1500", true)
        val warning = editField("Warning percentage (e.g. 80)", existing?.warningPercent?.toString() ?: "80", true)
        form.addView(fieldLabel("Vehicle name")); form.addView(name)
        form.addView(fieldLabel("Vehicle type")); form.addView(type)
        form.addView(fieldLabel("Registration number (optional)")); form.addView(registration)
        form.addView(fieldLabel("Current odometer reading (KM)")); form.addView(current)
        form.addView(fieldLabel("Last oil-change odometer reading (KM)")); form.addView(lastOil)
        form.addView(fieldLabel("Oil-change interval (KM)")); form.addView(interval)
        form.addView(fieldLabel("Warning percentage (1–99)")); form.addView(warning)
        val scroll = ScrollView(this).apply { addView(form) }
        val dialog = AlertDialog.Builder(this).setTitle(if (existing == null) "Add New Vehicle" else "Edit Vehicle")
            .setView(scroll).setNegativeButton("Cancel", null).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim()
                val c = parseKm(current.text.toString())
                val l = parseKm(lastOil.text.toString())
                val i = parseKm(interval.text.toString())
                val w = warning.text.toString().toIntOrNull()
                when {
                    n.isBlank() -> name.error = "Enter a vehicle name"
                    c == null || l == null || i == null || c < 0 || l < 0 || i <= 0 ->
                        Toast.makeText(this, "Enter non-negative odometer readings and a positive interval", Toast.LENGTH_LONG).show()
                    l > c -> Toast.makeText(this, "Last oil-change reading cannot exceed current reading", Toast.LENGTH_LONG).show()
                    existing != null && c < existing.currentKm ->
                        Toast.makeText(this, "Current odometer reading cannot be lower than the previous reading", Toast.LENGTH_LONG).show()
                    w == null || w !in 1..99 -> Toast.makeText(this, "Warning percentage must be between 1 and 99", Toast.LENGTH_LONG).show()
                    else -> {
                        if (existing == null) {
                            vehicles.add(Vehicle(System.currentTimeMillis(), n, type.selectedItem.toString(), registration.text.toString().trim(), c, l, i, w))
                        } else {
                            val thresholdsChanged = existing.intervalKm != i || existing.warningPercent != w
                            existing.name = n; existing.type = type.selectedItem.toString(); existing.registration = registration.text.toString().trim()
                            existing.currentKm = c; existing.intervalKm = i; existing.warningPercent = w
                            if (thresholdsChanged) { existing.warningSent = false; existing.dueSent = false }
                            // Last oil-change baseline and history are intentionally not editable after creation.
                        }
                        saveData(); dialog.dismiss(); render(); checkThresholds()
                    }
                }
            }
        }
        dialog.show()
    }

    private fun showKmDialog(v: Vehicle) {
        val input = editField("Current odometer reading (KM)", v.currentKm.toString(), true)
        AlertDialog.Builder(this).setTitle("Update ${v.name}").setView(input).setNegativeButton("Cancel", null)
            .setPositiveButton("Update", null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val km = parseKm(input.text.toString())
                    if (km == null || km < 0 || km < v.currentKm) input.error = "Enter a non-negative reading not below the current odometer"
                    else { v.currentKm = km; saveData(); d.dismiss(); render(); checkThresholds(v) }
                } }
                d.show()
            }
    }

    private fun showOilChangeDialog(v: Vehicle) {
        val input = editField("Odometer reading after oil change (KM)", v.currentKm.toString(), true)
        AlertDialog.Builder(this).setTitle("Confirm oil change – ${v.name}")
            .setMessage("Only confirm after the engine oil has actually been changed. This saves a permanent history record.")
            .setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save oil change", null).create().also { d ->
                d.setOnShowListener { d.getButton(-1).setOnClickListener {
                    val km = parseKm(input.text.toString())
                    if (km == null || km < 0 || km < v.currentKm) input.error = "Enter a non-negative reading not below the current odometer"
                    else {
                        val previous = v.lastOilKm
                        v.records.add(OilRecord(System.currentTimeMillis(), km, previous, v.intervalKm))
                        v.currentKm = km; v.lastOilKm = km; v.warningSent = false; v.dueSent = false
                        saveData(); d.dismiss(); render()
                        Toast.makeText(this, "Oil change saved in history", Toast.LENGTH_SHORT).show()
                    }
                } }
                d.show()
            }
    }

    private fun confirmDelete(v: Vehicle) {
        AlertDialog.Builder(this).setTitle("Delete ${v.name}?")
            .setMessage("This permanently deletes the vehicle and all its oil-change history. This cannot be undone.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete permanently") { _, _ -> vehicles.remove(v); saveData(); render() }.show()
    }

    private fun checkThresholds(only: Vehicle? = null) {
        val list = if (only == null) vehicles else listOf(only)
        list.forEach { v ->
            if (!v.warningSent && v.driven >= v.warningAt && v.driven < v.intervalKm) {
                v.warningSent = sendNotification(
                    v, "Oil change approaching",
                    "${v.name} has run ${v.driven} KM. Oil change is approaching."
                )
            }
            if (!v.dueSent && v.driven >= v.intervalKm) {
                v.dueSent = sendNotification(
                    v, "Oil change due",
                    "${v.name} has reached ${v.driven} KM. Please change the engine oil."
                )
            }
        }
        saveData()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("oil_reminders", "Oil change reminders", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
    }
    private fun sendNotification(v: Vehicle, title: String, message: String): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val builder = if (Build.VERSION.SDK_INT >= 26)
                android.app.Notification.Builder(this, "oil_reminders")
            else
                android.app.Notification.Builder(this)
            val notification = builder
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setAutoCancel(true)
                .build()
            manager.notify((v.id % Int.MAX_VALUE).toInt(), notification)
            true
        } catch (_: Exception) {
            false
        }
    }


    private fun editField(hintText: String, value: String, numeric: Boolean = false): EditText = EditText(this).apply {
        hint = hintText; setText(value); textSize = 16f; setTextColor(fg()); setHintTextColor(muted())
        inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        setPadding(dp(10), dp(7), dp(10), dp(7))
    }
    private fun fieldLabel(s: String) = TextView(this).apply { text = s; textSize = 12f; setTextColor(muted()); setPadding(0, dp(8), 0, 0) }
    private fun sectionTitle(s: String) = txt(s, 15, fg(), true)
    private fun emptyCard(title: String, body: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(18)); setBackgroundColor(card())
        addView(txt(title, 16, fg(), true)); addView(txt(body, 12, muted()))
    }
    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(62, 104, 205))
        setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8) }
    }
    private fun smallButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 11f; setTextColor(if (dark) Color.WHITE else textDark)
        backgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) cardDark else Color.rgb(225, 237, 253))
        setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(42)).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
    }
    private fun txt(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun simpleListener(onSelected: (String) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { onSelected(parent?.getItemAtPosition(position)?.toString() ?: "Default") }
    }
}
