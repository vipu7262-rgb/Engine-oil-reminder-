# Engine Oil Reminder – Android Studio project

A native Kotlin Android project for the Engine Oil Reminder app.

## Included in this project

- Racing Green visual theme and modern dashboard layout
- Default, Dark theme, and Automatic theme choices
- Four bottom tabs: Home, Vehicles, History, Settings
- Add multiple vehicles (Bike, Scooter, Car, Truck, Other)
- Vehicle name, type, optional registration, current odometer, last oil-change odometer, oil interval, and warning percentage
- Vehicle cards sorted alphabetically
- Full vehicle cards with current odometer, last oil-change reading, distance run, interval, progress, remaining distance, and status
- Manual and quick odometer updates
- Per-vehicle warning percentage and oil interval
- Warning and due notifications when a user updates the odometer and crosses the relevant threshold
- Explicit oil-change confirmation before resetting the distance counter
- Oil-change history records date, new reading, previous reading, distance run, and interval
- Vehicle editing while keeping previous oil-change baseline and history protected
- Permanent vehicle deletion with a confirmation dialog
- Local on-device data storage; no backup/restore and no app lock
- First-launch language selector listing English plus all 22 scheduled Indian languages

## Important implementation notes

1. **Notifications are evaluated when the user updates a vehicle's odometer.** The app cannot know real-world distance travelled automatically because it does not connect to the vehicle's odometer.
2. Android 13 and newer require notification permission. The app requests it when first launched.
3. The language picker includes English and all 22 scheduled Indian languages. This starter project currently stores the selected language, but the full interface translation catalog for all 23 choices is not yet bundled. Full professional translations and script/layout QA are required before claiming complete multilingual UI support.
4. Vehicle data is stored locally in app preferences. Uninstalling the app or clearing its data removes those records. There is no backup/restore feature, as requested.
5. Oil-change history is append-only in the UI. Editing a vehicle does not change past history records or its last oil-change baseline.

## Build an APK

This workspace contains the Android Studio source project, not a compiled APK. To build the APK:

1. Install Android Studio on a computer.
2. Open this `EngineOilReminder_Final` folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if Android Studio requests it.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK output location.

Recommended final QA before release: test add/edit/delete, odometer corrections, threshold crossings, notifications on Android 13+, theme changes including system dark-mode changes, and each localized UI translation after it is added.
